---
name: Other Issue
about: Ask your question, if it's not a bug or feature request
title: ''
labels: ''
assignees: ''

---

**Environment (please complete the following information):**
 - PHP IMAP version: [e.g. 3.0.11]
 - PHP Version: [e.g. 7.1.26]
 - Type of execution: [e.g. Daemon / CLI or Web Server]

**Your Text**
A clear and concise description of what you want.
